package com.example.homecaresquad;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class ServiceDetailsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_service_details);

        // Retrieve service details from intent extras
        String serviceName = getIntent().getStringExtra("serviceName");
        double basicCost = getIntent().getDoubleExtra("basicCost", 0);
        double standardCost = getIntent().getDoubleExtra("standardCost", 0);
        double premiumCost = getIntent().getDoubleExtra("premiumCost", 0);

        // Display service details in the layout
        TextView serviceNameTextView = findViewById(R.id.serviceNameTextView);
        TextView basicCostTextView = findViewById(R.id.basicCostTextView);
        TextView standardCostTextView = findViewById(R.id.standardCostTextView);
        TextView premiumCostTextView = findViewById(R.id.premiumCostTextView);

        serviceNameTextView.setText(serviceName);
        basicCostTextView.setText("Basic Cost: $" + basicCost);
        standardCostTextView.setText("Standard Cost: $" + standardCost);
        premiumCostTextView.setText("Premium Cost: $" + premiumCost);

        // Set click listeners for the buttons
        TextView basicButton = findViewById(R.id.basicCostTextView);
        TextView standardButton = findViewById(R.id.standardCostTextView);
        TextView premiumButton = findViewById(R.id.premiumCostTextView);

        basicButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle basic service click
                scheduleAppointment(serviceName, basicCost);
            }
        });

        standardButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle standard service click
                scheduleAppointment(serviceName, standardCost);
            }
        });

        premiumButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle premium service click
                scheduleAppointment(serviceName, premiumCost);
            }
        });
    }

    private void scheduleAppointment(String serviceName, double cost) {
        // Pass service details to AppointmentActivity
        Intent intent = new Intent(ServiceDetailsActivity.this, AppointmentActivity.class);
        intent.putExtra("serviceName", serviceName);
        intent.putExtra("cost", cost);
        startActivity(intent);
    }

}
