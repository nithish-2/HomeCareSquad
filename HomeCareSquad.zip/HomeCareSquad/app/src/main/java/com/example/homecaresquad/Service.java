package com.example.homecaresquad;
import android.os.Parcel;
import android.os.Parcelable;

public class Service implements Parcelable {
    private String name;
    private int imageResourceId;
    private double basicCost;
    private double standardCost;
    private double premiumCost;

    public Service(String name, double basicCost, double standardCost, double premiumCost) {
        this.name = name;
        this.basicCost = basicCost;
        this.standardCost = standardCost;
        this.premiumCost = premiumCost;
    }

    protected Service(Parcel in) {
        name = in.readString();
        imageResourceId = in.readInt();
        basicCost = in.readDouble();
        standardCost = in.readDouble();
        premiumCost = in.readDouble();
    }

    public static final Creator<Service> CREATOR = new Creator<Service>() {
        @Override
        public Service createFromParcel(Parcel in) {
            return new Service(in);
        }

        @Override
        public Service[] newArray(int size) {
            return new Service[size];
        }
    };

    public String getName() {
        return name;
    }

    public int getImageResourceId() {
        return imageResourceId;
    }

    public double getBasicCost() {
        return basicCost;
    }

    public double getStandardCost() {
        return standardCost;
    }

    public double getPremiumCost() {
        return premiumCost;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(name);
        dest.writeInt(imageResourceId);
        dest.writeDouble(basicCost);
        dest.writeDouble(standardCost);
        dest.writeDouble(premiumCost);
    }
}
