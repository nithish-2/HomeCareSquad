package com.example.homecaresquad;

import android.os.Bundle;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class AddToCartActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_to_cart);

        ArrayList<Service> selectedServices = getIntent().getParcelableArrayListExtra("selectedServices");

        if (selectedServices != null) {
            Log.d("AddToCartActivity", "Selected services size: " + selectedServices.size());

            // Display selected services in the UI
            RecyclerView recyclerView = findViewById(R.id.selected_services_recycler_view);
            recyclerView.setLayoutManager(new LinearLayoutManager(this));
            ServiceAdapter adapter = new ServiceAdapter(this, selectedServices);
            recyclerView.setAdapter(adapter);
        } else {
            Log.e("AddToCartActivity", "Selected services is null");
            // Handle the case when selectedServices is null, maybe show a message or finish the activity
            finish();
        }
    }
}
