package com.example.homecaresquad;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class AppointmentActivity extends AppCompatActivity {

    private TextView serviceNameTextView;
    private TextView selectedDateTextView;
    private TextView selectedTimeTextView;
    private Button dateButton;
    private Button timeButton;
    private Button submitButton;

    private ServiceAdapter adapter; // Add this line

    private Calendar calendar;

    private List<Service> selectedServices = new ArrayList<>();
    private DatePickerDialog.OnDateSetListener dateSetListener;
    private TimePickerDialog.OnTimeSetListener timeSetListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_appointment);

        serviceNameTextView = findViewById(R.id.serviceNameTextView);
        selectedDateTextView = findViewById(R.id.selectedDateTextView);
        selectedTimeTextView = findViewById(R.id.selectedTimeTextView);
        dateButton = findViewById(R.id.dateButton);
        timeButton = findViewById(R.id.timeButton);
        submitButton = findViewById(R.id.submitAppointmentButton);

        // Retrieve service name from intent extras
        String serviceName = getIntent().getStringExtra("serviceName");
        serviceNameTextView.setText(serviceName);

        calendar = Calendar.getInstance();

        // Date Picker Dialog
        dateSetListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                calendar.set(Calendar.YEAR, year);
                calendar.set(Calendar.MONTH, month);
                calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                updateDateLabel();
            }
        };

        // Time Picker Dialog
        timeSetListener = new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                calendar.set(Calendar.HOUR_OF_DAY, hourOfDay);
                calendar.set(Calendar.MINUTE, minute);
                updateTimeLabel();
            }
        };

        // Date Button Click Listener
        dateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new DatePickerDialog(AppointmentActivity.this, dateSetListener,
                        calendar.get(Calendar.YEAR),
                        calendar.get(Calendar.MONTH),
                        calendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        // Time Button Click Listener
        timeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new TimePickerDialog(AppointmentActivity.this, timeSetListener,
                        calendar.get(Calendar.HOUR_OF_DAY),
                        calendar.get(Calendar.MINUTE),
                        true).show();
            }
        });

        // Submit Button Click Listener
        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get the selected date and time
                String selectedDate = selectedDateTextView.getText().toString();
                String selectedTime = selectedTimeTextView.getText().toString();

                // Retrieve service details from intent extras
                String serviceName = getIntent().getStringExtra("serviceName");
                double cost = getIntent().getDoubleExtra("cost", 0.0);

                // Add the selected service to the list
                selectedServices.add(new Service(serviceName, cost, cost, cost)); // Remove the drawable parameter

                // Notify the user about the scheduled appointment
                String message = "Appointment scheduled for:\nDate: " + selectedDate + "\nTime: " + selectedTime;
                Toast.makeText(AppointmentActivity.this, message, Toast.LENGTH_LONG).show();

                Intent intent = new Intent(AppointmentActivity.this, AddToCartActivity.class);
                intent.putParcelableArrayListExtra("selectedServices", (ArrayList<? extends Parcelable>) selectedServices);
                startActivity(intent);

            }
        });

    }

    private void updateDateLabel() {
        String dateFormat = "MM/dd/yyyy";
        SimpleDateFormat sdf = new SimpleDateFormat(dateFormat, Locale.US);
        selectedDateTextView.setText(sdf.format(calendar.getTime()));
    }

    private void updateTimeLabel() {
        String timeFormat = "hh:mm a";
        SimpleDateFormat sdf = new SimpleDateFormat(timeFormat, Locale.US);
        selectedTimeTextView.setText(sdf.format(calendar.getTime()));
    }
}
